initSqlJs({ locateFile: filename => `https://cdnjs.cloudflare.com/ajax/libs/sql.js/1.5.0/${filename}` })
    .then(SQL => {
        let db = new SQL.Database(); // Создаём виртуальную базу данных
        db.exec("CREATE TABLE test (Path); INSERT INTO test VALUES ('images/product-1.jpg'), ('images/product-2.jpg'), ('images/product-3.jpg'), ('images/product-4.jpg')"); // Заполняем таблицу тестовыми данными
        let stmt = db.prepare("SELECT * FROM test"); 

        const arr = [];

        while (stmt.step()){
            arr.push(stmt.get()); 
        } 
        //stmt.free(); // Освобождаем ресурсы после выполнения запроса

         const container1 = document.getElementById('image-container-1');
        
         for (let i = 0; i < arr.length; i += 1) {  
                const img = document.createElement('img');       
                img.src = arr[i];
                img.height = 200; // Тут можно менять для размера картинок в галерее
                container1.appendChild(img);
          }

          const container2 = document.getElementById('image-container-2');
        
         for (let i = 0; i < arr.length; i += 1) {  
                const img = document.createElement('img');       
                img.src = arr[i];
                img.height = 200; // Тут можно менять для размера картинок в галерее
                container2.appendChild(img);
          }


          const container3 = document.getElementById('image-container-3');
        
         for (let i = 0; i < arr.length; i += 1) {  
                const img = document.createElement('img');       
                img.src = arr[i];
                img.height = 200; // Тут можно менять для размера картинок в галерее
                container3.appendChild(img);
          }


          const container4 = document.getElementById('image-container-4');
        
         for (let i = 0; i < arr.length; i += 1) {  
                const img = document.createElement('img');       
                img.src = arr[i];
                img.height = 200; // Тут можно менять для размера картинок в галерее
                container4.appendChild(img);
          }

    }); 