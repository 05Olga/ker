

CREATE TABLE `orders`(
    `order_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `customer_id` INT NOT NULL,
    `order_date` DATE NOT NULL,
    `status` VARCHAR(255) NOT NULL,
    `total_price` DECIMAL(8, 2) NOT NULL,
    PRIMARY KEY(`customer_id`)
);
CREATE TABLE `client`(
    `customer_id` INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    `first_name` VARCHAR(255) NOT NULL,
    `last_name` VARCHAR(255) NOT NULL,
    `email` VARCHAR(255) NOT NULL
);
CREATE TABLE `categories`(
    `category_id` INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    `name` VARCHAR(255) NOT NULL
);
ALTER TABLE
    `order_details` ADD CONSTRAINT `order_details_order_id_foreign` FOREIGN KEY(`order_id`) REFERENCES `orders`(`order_id`);
ALTER TABLE
    `products` ADD CONSTRAINT `products_supplier_id_foreign` FOREIGN KEY(`supplier_id`) REFERENCES `suppliers`(`supplier_id`);
ALTER TABLE
    `categories` ADD CONSTRAINT `categories_category_id_foreign` FOREIGN KEY(`category_id`) REFERENCES `products`(`category_id`);
ALTER TABLE
    `products` ADD CONSTRAINT `products_product_id_foreign` FOREIGN KEY(`product_id`) REFERENCES `order_details`(`product_id`);
ALTER TABLE
    `client` ADD CONSTRAINT `client_customer_id_foreign` FOREIGN KEY(`customer_id`) REFERENCES `orders`(`customer_id`);